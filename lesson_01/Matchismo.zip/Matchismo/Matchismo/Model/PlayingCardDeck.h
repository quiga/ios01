//
//  PlayingCardDeck.h
//  Matchismo
//
//  Created by Trollface on 2014.03.04..
//  Copyright (c) 2014 Quiga. All rights reserved.
//

#import "Deck.h"

@interface PlayingCardDeck : Deck



@end
