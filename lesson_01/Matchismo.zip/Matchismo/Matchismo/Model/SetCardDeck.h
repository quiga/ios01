//
//  SetCardDeck.h
//  Matchismo
//
//  Created by PPKE-IMAC-4 on 2014.03.27..
//  Copyright (c) 2014 Quiga. All rights reserved.
//

#import "Deck.h"
#import "Card.h"
#import "SetCard.h"

@interface SetCardDeck : Deck

@end
